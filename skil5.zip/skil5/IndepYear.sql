SELECT Name, IndepYear FROM 0908012440_skilaverkefni_5.country
WHERE
IndepYear > 1920
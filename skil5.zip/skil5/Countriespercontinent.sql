SELECT count(Name) AS CountyCount,Continent FROM 0908012440_skilaverkefni_5.country
GROUP BY
Continent
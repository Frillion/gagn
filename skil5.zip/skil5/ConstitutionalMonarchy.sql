SELECT Name,GovernmentForm FROM 0908012440_skilaverkefni_5.country
WHERE
GovernmentForm = 'Constitutional Monarchy'
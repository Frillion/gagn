SELECT Name,continent,population FROM 0908012440_skilaverkefni_5.country
WHERE
Continent = 'Asia'
And
Population > 10000000

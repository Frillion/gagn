SELECT count(Name),GovernmentForm FROM 0908012440_skilaverkefni_5.country
GROUP BY GovernmentForm
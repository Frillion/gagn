SELECT Name,Continent FROM 0908012440_skilaverkefni_5.country
WHERE
Continent='Europe'
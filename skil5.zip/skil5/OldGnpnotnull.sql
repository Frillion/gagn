SELECT Name, GNPOld FROM 0908012440_skilaverkefni_5.country
WHERE
GNPOld != 0
SELECT SUM(GNP) AS TotalGNP FROM 0908012440_skilaverkefni_5.country

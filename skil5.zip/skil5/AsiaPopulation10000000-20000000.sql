SELECT Name, Population FROM 0908012440_skilaverkefni_5.country
WHERE
Continent = 'Asia' and Population > 10000000 and Population < 20000000
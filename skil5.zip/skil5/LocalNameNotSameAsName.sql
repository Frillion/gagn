SELECT Name, LocalName FROM 0908012440_skilaverkefni_5.country
WHERE	
Name != LocalName
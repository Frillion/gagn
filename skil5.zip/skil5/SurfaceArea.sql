SELECT Name,SurfaceArea FROM 0908012440_skilaverkefni_5.country
WHERE
SurfaceArea > 600000
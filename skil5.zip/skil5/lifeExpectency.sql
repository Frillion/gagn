SELECT cast(sum(LifeExpectancy)/count(*) AS DECIMAL(5,3)) AS Total_LifeExpectancy FROM 0908012440_skilaverkefni_5.country
